import { useState, useEffect } from 'react';
import { Link, usePage, router } from '@inertiajs/react';
import {
    Calendar,
    Users,
    FileSpreadsheet,
    Settings,
    LogOut,
    Shield,
    Menu,
    X,
    ExternalLink,
    CheckCheck,
    Clock,
    PanelLeftClose,
    PanelLeftOpen,
    ChevronLeft,
    ChevronRight,
    CreditCard,
    HelpCircle,
    Store,
    AlertOctagon,
} from 'lucide-react';
import { showSuccess, showError, showWarning, showToast } from '@/lib/swal';
import Swal from 'sweetalert2';
import ThemeToggle from '@/components/theme-toggle';
import AdminBottomNav from '@/components/admin-bottom-nav';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface Props {
    children: React.ReactNode;
    title?: string;
}

export default function AdminLayout({ children, title }: Props) {
    const { auth, flash, settings } = usePage<any>().props;
    const [isMinimized, setIsMinimized] = useState(() => {
        if (typeof window !== 'undefined') {
            return localStorage.getItem('admin_sidebar_minimized') === 'true';
        }
        return false;
    });

    const toggleMinimize = () => {
        setIsMinimized((prev) => {
            const next = !prev;
            if (typeof window !== 'undefined') {
                localStorage.setItem('admin_sidebar_minimized', String(next));
            }
            return next;
        });
    };

    // Keyboard shortcut: Ctrl + B / Cmd + B to toggle sidebar minimize/maximize
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
                e.preventDefault();
                toggleMinimize();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    // Handle flash messages using SweetAlert2
    useEffect(() => {
        if (flash?.success) {
            if (flash?.new_verification_link) {
                Swal.fire({
                    title: 'New Verification Link Generated!',
                    html: `
                        <p class="text-sm text-gray-500 mb-3">${flash.success}</p>
                        <div class="p-3 bg-gray-100 dark:bg-gray-800 rounded text-xs font-mono break-all select-all text-blue-600 dark:text-blue-400 mb-4">
                            ${flash.new_verification_link}
                        </div>
                        <p class="text-xs text-gray-400">Send this single-use link to the employee's registered device.</p>
                    `,
                    icon: 'success',
                    showCancelButton: true,
                    confirmButtonText: 'Copy Link',
                    cancelButtonText: 'Close',
                    customClass: {
                        confirmButton: 'bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium text-sm',
                        cancelButton: 'bg-secondary text-secondary-foreground px-4 py-2 rounded-md font-medium text-sm ml-2',
                    },
                    buttonsStyling: false,
                }).then((res) => {
                    if (res.isConfirmed) {
                        navigator.clipboard.writeText(flash.new_verification_link);
                        showToast('Link copied to clipboard!', 'success');
                    }
                });
            } else {
                showSuccess(flash.success);
            }
        }
        if (flash?.error) {
            showError(flash.error);
        }
        if (flash?.warning) {
            showWarning(flash.warning);
        }
    }, [flash]);

    const handleLogout = () => {
        router.post('/store/logout');
    };

    const currentRoute = window.location.pathname;

    const navItems = [
        {
            label: 'Dashboard & Shifts',
            href: '/store/dashboard',
            icon: Calendar,
            active: currentRoute.includes('/store/dashboard') || currentRoute === '/store' || currentRoute === '/store/' || currentRoute.includes('/administration-control'),
        },
        {
            label: 'Employees',
            href: '/store/employees',
            icon: Users,
            active: currentRoute.includes('/store/employees') || currentRoute.includes('/administration-control/employees'),
        },
        {
            label: 'Monthly Reports',
            href: '/store/reports',
            icon: FileSpreadsheet,
            active: currentRoute.includes('/store/reports') || currentRoute.includes('/administration-control/reports'),
        },
        ...(!auth?.admin?.is_lifetime_free ? [
            {
                label: 'Invoices & Billing',
                href: '/store/invoices',
                icon: CreditCard,
                active: currentRoute.includes('/store/invoices'),
            }
        ] : []),
        {
            label: 'Store Settings',
            href: '/store/settings',
            icon: Settings,
            active: currentRoute.includes('/store/settings') || currentRoute.includes('/administration-control/settings'),
        },
        {
            label: 'User Manual',
            href: '/store/user-manual',
            icon: HelpCircle,
            active: currentRoute.includes('/store/user-manual'),
        },
    ];

    const brandname = settings?.brandname || 'AttendEase Pro';

    return (
        <TooltipProvider delayDuration={150}>
            <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col antialiased">
                {/* Mobile & Tablet Header (Clean app header - no hamburger, navigation is in the bottom bar) */}
                <div className="lg:hidden sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
                    <div className="flex items-center gap-2">
                        <Link href="/store/dashboard" className="flex items-center gap-2 overflow-hidden min-w-0">
                            {settings?.logo ? (
                                <img src={`/storage/${settings.logo}`} alt="Logo" className="h-7 w-auto max-w-[140px] object-contain dark:invert dark:brightness-0" />
                            ) : (
                                <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                                    <div className="h-7 w-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-sm shadow-indigo-600/30 shrink-0">
                                        <Shield className="h-4 w-4" />
                                    </div>
                                    <span className="text-sm font-bold truncate">{brandname}</span>
                                </div>
                            )}
                        </Link>
                    </div>
                    <div className="flex items-center gap-2">
                        <ThemeToggle variant="dropdown" />
                        <div className="flex items-center gap-1.5 pl-1.5 border-l border-slate-200 dark:border-slate-800">
                            <div className="h-8 w-8 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800/60 flex items-center justify-center font-bold text-indigo-700 dark:text-indigo-300 text-xs shrink-0">
                                {auth?.admin?.name?.substring(0, 2).toUpperCase() || 'AD'}
                            </div>
                            <button
                                onClick={handleLogout}
                                title="Log Out"
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer"
                                aria-label="Log Out"
                            >
                                <LogOut className="h-4 w-4" />
                            </button>
                        </div>
                    </div>
                </div>

                <div className="flex-1 flex">
                    {/* Desktop Sidebar Navigation */}
                    <aside
                        className={cn(
                            "hidden lg:flex fixed inset-y-0 left-0 z-40 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex-col transition-all duration-300 ease-in-out",
                            isMinimized ? "w-20" : "w-64"
                        )}
                    >
                        {/* Brand header */}
                        <div className={`p-4 border-b border-slate-200 dark:border-slate-800 flex items-center h-[65px] transition-all duration-300 ${isMinimized ? 'justify-center px-2' : 'justify-between px-5'
                            }`}>
                            {/* Expanded state on desktop or mobile view */}
                            <div className={cn("flex items-center justify-between w-full min-w-0", isMinimized && "lg:hidden")}>
                                <Link href="/store/dashboard" className="flex items-center gap-2.5 overflow-hidden min-w-0">
                                    {settings?.logo ? (
                                        <img src={`/storage/${settings.logo}`} alt="Logo" className="max-h-8 w-auto max-w-[150px] object-contain dark:invert dark:brightness-0" />
                                    ) : (
                                        <div className="flex items-center gap-2.5 font-bold text-base text-slate-900 dark:text-white tracking-tight">
                                            <div className="h-8 w-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-sm shadow-indigo-600/30 shrink-0">
                                                <Shield className="h-4 w-4" />
                                            </div>
                                            <span className="truncate">{brandname}</span>
                                        </div>
                                    )}
                                </Link>
                            </div>

                            {/* Minimized state on desktop */}
                            <div className={cn("hidden", isMinimized && "lg:flex items-center justify-center w-full")}>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Link
                                            href="/store/dashboard"
                                            className="flex items-center justify-center p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                                            aria-label={brandname}
                                        >
                                            {settings?.favicon ? (
                                                <img src={`/storage/${settings.favicon}`} alt="Logo" className="h-7 w-7 object-contain" />
                                            ) : settings?.logo ? (
                                                <img src={`/storage/${settings.logo}`} alt="Logo" className="h-7 w-7 object-contain dark:invert dark:brightness-0" />
                                            ) : (
                                                <div className="h-8 w-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-sm shadow-indigo-600/30">
                                                    <Shield className="h-4 w-4" />
                                                </div>
                                            )}
                                        </Link>
                                    </TooltipTrigger>
                                    <TooltipContent side="right" sideOffset={12}>
                                        {brandname}
                                    </TooltipContent>
                                </Tooltip>
                            </div>
                        </div>

                        {/* Nav Items */}
                        <nav className={cn("flex-1 p-3 space-y-1.5 overflow-y-auto transition-all", isMinimized ? "lg:px-2 px-4" : "px-4")}>
                            <div className={cn("text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-3 mb-2", isMinimized && "lg:hidden")}>
                                Menu
                            </div>
                            <div className={cn("hidden my-2 border-t border-slate-100 dark:border-slate-800 mx-2", isMinimized && "lg:block")} />

                            {navItems.map((item) => {
                                const Icon = item.icon;
                                const linkElement = (
                                    <Link
                                        key={item.href}
                                        href={item.href}
                                        className={cn(
                                            "flex items-center rounded-lg text-sm font-medium transition-all group",
                                            isMinimized
                                                ? "gap-3 px-3.5 py-2.5 lg:justify-center lg:p-2.5 lg:gap-0"
                                                : "gap-3 px-3.5 py-2.5",
                                            item.active
                                                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
                                                : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white"
                                        )}
                                    >
                                        <Icon className={cn("h-4 w-4 shrink-0", item.active ? "text-white" : "text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300")} />
                                        <span className={cn("truncate ml-3 transition-opacity duration-200", isMinimized && "lg:hidden")}>
                                            {item.label}
                                        </span>
                                    </Link>
                                );

                                if (isMinimized) {
                                    return (
                                        <Tooltip key={item.href}>
                                            <TooltipTrigger asChild>
                                                {linkElement}
                                            </TooltipTrigger>
                                            <TooltipContent side="right" sideOffset={12} className="hidden lg:block">
                                                {item.label}
                                            </TooltipContent>
                                        </Tooltip>
                                    );
                                }

                                return linkElement;
                            })}

                            <div className="pt-4 mt-4 border-t border-slate-200 dark:border-slate-800">
                                <div className={cn("text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 px-3 mb-2", isMinimized && "lg:hidden")}>
                                    Public Portals
                                </div>
                                <div className={cn("hidden my-1 border-t border-slate-100 dark:border-slate-800 mx-2", isMinimized && "lg:block")} />

                                {isMinimized ? (
                                    <Tooltip>
                                        <TooltipTrigger asChild>
                                            <a
                                                href="/attendance"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="flex items-center justify-between px-3.5 py-2.5 lg:justify-center lg:p-2.5 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors group"
                                            >
                                                <Clock className="h-4 w-4 text-emerald-500 shrink-0" />
                                                <span className="truncate ml-3 lg:hidden">Employee Portal</span>
                                                <ExternalLink className="h-3.5 w-3.5 text-slate-400 group-hover:text-slate-600 lg:hidden" />
                                            </a>
                                        </TooltipTrigger>
                                        <TooltipContent side="right" sideOffset={12} className="hidden lg:block">
                                            Employee Portal (Open in new tab)
                                        </TooltipContent>
                                    </Tooltip>
                                ) : (
                                    <a
                                        href="/attendance"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors group"
                                    >
                                        <span className="flex items-center gap-2.5">
                                            <Clock className="h-4 w-4 text-emerald-500" />
                                            Employee Portal
                                        </span>
                                        <ExternalLink className="h-3.5 w-3.5 text-slate-400 group-hover:text-slate-600" />
                                    </a>
                                )}
                            </div>
                        </nav>

                        {/* Admin User Footer Profile */}
                        <div className={cn("border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 transition-all", isMinimized ? "lg:p-2.5 p-4" : "p-4")}>
                            {/* Full profile for expanded desktop or mobile */}
                            <div className={cn("flex items-center justify-between", isMinimized && "lg:hidden")}>
                                <div className="flex items-center gap-3 min-w-0">
                                    <div className="h-9 w-9 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-700 dark:text-slate-200 text-xs shrink-0">
                                        {auth?.admin?.name?.substring(0, 2).toUpperCase() || 'AD'}
                                    </div>
                                    <div className="truncate">
                                        <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                                            {auth?.admin?.name || 'Administrator'}
                                        </p>
                                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                                            {auth?.admin?.email}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1">
                                    <ThemeToggle variant="dropdown" className="border-0 bg-transparent shadow-none" />
                                    <button
                                        onClick={handleLogout}
                                        title="Log Out"
                                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer"
                                    >
                                        <LogOut className="h-4 w-4" />
                                    </button>
                                </div>
                            </div>

                            {/* Compact profile for minimized desktop */}
                            <div className={cn("hidden", isMinimized && "lg:flex flex-col items-center gap-2")}>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <div className="h-9 w-9 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-700 dark:text-slate-200 text-xs shrink-0 cursor-default">
                                            {auth?.admin?.name?.substring(0, 2).toUpperCase() || 'AD'}
                                        </div>
                                    </TooltipTrigger>
                                    <TooltipContent side="right" sideOffset={12}>
                                        <p className="font-semibold">{auth?.admin?.name || 'Administrator'}</p>
                                        <p className="text-xs text-slate-400">{auth?.admin?.email}</p>
                                    </TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <button
                                            onClick={handleLogout}
                                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer"
                                            aria-label="Log Out"
                                        >
                                            <LogOut className="h-4 w-4" />
                                        </button>
                                    </TooltipTrigger>
                                    <TooltipContent side="right" sideOffset={12}>
                                        Log Out
                                    </TooltipContent>
                                </Tooltip>
                            </div>
                        </div>
                    </aside>

                    {/* Main Content Area */}
                    <main className={cn(
                        "flex-1 flex flex-col min-w-0 transition-all duration-300 ease-in-out",
                        isMinimized ? "lg:pl-20" : "lg:pl-64"
                    )}>
                        <header className="sticky top-0 z-20 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-6 py-3.5 hidden lg:flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <button
                                    onClick={toggleMinimize}
                                    className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                                    title={isMinimized ? "Maximize sidebar (Ctrl+B)" : "Minimize sidebar (Ctrl+B)"}
                                    aria-label={isMinimized ? "Maximize sidebar" : "Minimize sidebar"}
                                >
                                    {isMinimized ? (
                                        <PanelLeftOpen className="h-5 w-5" />
                                    ) : (
                                        <PanelLeftClose className="h-5 w-5" />
                                    )}
                                </button>
                                <h2 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">
                                    {title || 'Administration Portal'}
                                </h2>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 text-xs font-medium border border-emerald-200 dark:border-emerald-800/40">
                                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                                    Session Active ({auth?.admin?.session_time || 30}m timeout)
                                </div>
                            </div>
                        </header>

                        <div className="flex-1 p-4 md:p-6 lg:p-8 pb-24 sm:pb-28 lg:pb-8 max-w-9xl w-full mx-auto">
                            {auth?.admin?.is_suspended && (
                                <div className="mb-6 rounded-2xl border border-rose-200 bg-rose-50/90 p-4 text-rose-900 shadow-sm dark:border-rose-900/60 dark:bg-rose-950/40 dark:text-rose-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                    <div className="flex items-start sm:items-center gap-3">
                                        <div className="h-10 w-10 rounded-xl bg-rose-100 dark:bg-rose-900/60 flex items-center justify-center text-rose-600 dark:text-rose-400 shrink-0 font-bold">
                                            <AlertOctagon className="h-5 w-5" />
                                        </div>
                                        <div>
                                            <h4 className="text-xs font-bold uppercase tracking-wider text-rose-700 dark:text-rose-300">
                                                Attendance Service Suspended &bull; Subscription Overdue
                                            </h4>
                                            <p className="text-xs text-rose-800 dark:text-rose-300/90 mt-0.5">
                                                The monthly attendance service is currently suspended due to an unpaid invoice past the deadline. Employees cannot record attendance until cleared.
                                            </p>
                                        </div>
                                    </div>
                                    <Link
                                        href="/store/invoices"
                                        className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md shadow-rose-600/20 transition-all shrink-0 cursor-pointer"
                                    >
                                        <CreditCard className="h-3.5 w-3.5" />
                                        <span>View & Pay Invoice</span>
                                    </Link>
                                </div>
                            )}

                            {children}
                        </div>
                    </main>
                </div>

                {/* Mobile & Tablet App Bottom Navigation Menu */}
                <AdminBottomNav
                    currentRoute={currentRoute}
                    auth={auth}
                    onLogout={handleLogout}
                />
            </div>
        </TooltipProvider>
    );
}
