<?php

use App\Http\Controllers\Admin\AttendanceController as AdminAttendanceController;
use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\EmployeeController as AdminEmployeeController;
use App\Http\Controllers\Admin\InvoiceController as AdminInvoiceController;
use App\Http\Controllers\Admin\OutletController as AdminOutletController;
use App\Http\Controllers\Admin\ReportController as AdminReportController;
use App\Http\Controllers\Admin\SettingsController as AdminSettingsController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\Employee\AttendancePageController;
use App\Http\Controllers\Employee\VerificationController;
use App\Http\Controllers\UserManualController;
use App\Models\WebsiteSetting;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Home redirects to Employee Attendance portal
Route::get('/', function () {
    return redirect()->route('attendance.index');
})->name('home');

// Dynamic Web App Manifest (PWA standalone browser support with dynamic favicon and brandname)
Route::get('/manifest.json', function () {
    $settings = WebsiteSetting::current();
    $brandname = ! empty($settings->brandname) ? $settings->brandname : config('app.name', 'AttendEase Pro');

    $faviconUrl = ! empty($settings->favicon)
        ? asset('storage/'.$settings->favicon)
        : asset('favicon.ico');

    $faviconExt = ! empty($settings->favicon)
        ? strtolower(pathinfo($settings->favicon, PATHINFO_EXTENSION))
        : 'ico';

    $faviconMime = match ($faviconExt) {
        'png' => 'image/png',
        'svg' => 'image/svg+xml',
        'jpg', 'jpeg' => 'image/jpeg',
        'webp' => 'image/webp',
        'gif' => 'image/gif',
        default => 'image/x-icon',
    };

    return response()->json([
        'name' => $brandname,
        'short_name' => $brandname,
        'description' => 'Real-time Attendance and Employee Management Portal',
        'start_url' => '/',
        'scope' => '/',
        'display' => 'standalone',
        'orientation' => 'portrait',
        'background_color' => '#ffffff',
        'theme_color' => '#4f46e5',
        'icons' => [
            [
                'src' => $faviconUrl,
                'sizes' => '192x192',
                'type' => $faviconMime,
                'purpose' => 'any maskable',
            ],
            [
                'src' => $faviconUrl,
                'sizes' => '512x512',
                'type' => $faviconMime,
                'purpose' => 'any maskable',
            ],
            [
                'src' => $faviconUrl,
                'sizes' => 'any',
                'type' => $faviconMime,
                'purpose' => 'any maskable',
            ],
        ],
    ], 200, [
        'Content-Type' => 'application/manifest+json; charset=utf-8',
        'Cache-Control' => 'no-cache, private',
    ]);
})->name('manifest.json');

// Alias for standard Laravel 'login' route name
Route::get('/login', function () {
    return redirect()->route('admin.login');
})->name('login');

/*
|--------------------------------------------------------------------------
| Employee Verification & Attendance Portal
|--------------------------------------------------------------------------
*/
// Single-use device verification link
Route::get('/verify/{token}', [VerificationController::class, 'verify'])->name('employee.verify');

// Public attendance page
Route::get('/attendance', [AttendancePageController::class, 'index'])->name('attendance.index');
Route::get('/attendance/suspended', [AttendancePageController::class, 'suspended'])->name('attendance.suspended');

// Protected attendance action endpoints (Office IP + Registered Device Token)
Route::prefix('attendance')->middleware(['verify.device', 'office.network'])->group(function () {
    Route::get('/status', [AttendancePageController::class, 'status'])->name('attendance.status');
    Route::post('/check-in', [AttendancePageController::class, 'checkIn'])->name('attendance.check-in');
    Route::post('/check-out', [AttendancePageController::class, 'checkOut'])->name('attendance.check-out');
    Route::get('/history', [AttendancePageController::class, 'history'])->name('attendance.history');
});

// Public User Manual page
Route::get('/user-manual', [UserManualController::class, 'publicIndex'])->name('user-manual.public');

/*
|--------------------------------------------------------------------------
| Surface Website Contact Page for Store Owners
| Captcha verification (JS frontend) + OTP verification + Inquiry Submission
|--------------------------------------------------------------------------
*/
Route::get('/contact', [ContactController::class, 'index'])->name('contact.index');
Route::post('/contact/send-otp', [ContactController::class, 'sendOtp'])->name('contact.send-otp');
Route::post('/contact/verify-otp', [ContactController::class, 'verifyOtp'])->name('contact.verify-otp');
Route::post('/contact', [ContactController::class, 'submit'])->name('contact.submit');

/*
|--------------------------------------------------------------------------
| Store / Administration Control Routes (Admin / Store Owner)
| Prefix: /store (previously /administration-control)
|--------------------------------------------------------------------------
*/
Route::prefix('store')->name('admin.')->group(function () {
    // Guest Admin Auth routes
    Route::middleware('guest:admin')->group(function () {
        Route::get('/login', [AdminAuthController::class, 'showLogin'])->name('login');
        Route::post('/login', [AdminAuthController::class, 'login'])->name('login.post');
        Route::get('/otp', [AdminAuthController::class, 'showOtp'])->name('otp.show');
        Route::post('/otp', [AdminAuthController::class, 'verifyOtp'])->name('otp.verify');
        Route::post('/otp/resend', [AdminAuthController::class, 'resendOtp'])->name('otp.resend');
    });

    // Authenticated Admin routes with Session Inactivity Timeout Middleware
    Route::middleware(['auth:admin', 'admin.timeout'])->group(function () {
        Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

        // Dashboard & Calendar
        Route::get('/', [AdminDashboardController::class, 'index'])->name('index');
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

        // Employees CRUD & Re-verification
        Route::get('/employees', [AdminEmployeeController::class, 'index'])->name('employees.index');
        Route::post('/employees', [AdminEmployeeController::class, 'store'])->name('employees.store');
        Route::post('/employees/{employee}', [AdminEmployeeController::class, 'update'])->name('employees.update');
        Route::delete('/employees/{employee}', [AdminEmployeeController::class, 'destroy'])->name('employees.destroy');
        Route::post('/employees/{employee}/reset-verification', [AdminEmployeeController::class, 'resetVerification'])->name('employees.reset-verification');

        // Manual Attendance Management
        Route::post('/attendances', [AdminAttendanceController::class, 'store'])->name('attendances.store');
        Route::put('/attendances/{attendance}', [AdminAttendanceController::class, 'update'])->name('attendances.update');
        Route::delete('/attendances/{attendance}', [AdminAttendanceController::class, 'destroy'])->name('attendances.destroy');

        // Monthly Reports & XLSX Export
        Route::get('/reports', [AdminReportController::class, 'index'])->name('reports.index');
        Route::get('/reports/export', [AdminReportController::class, 'export'])->name('reports.export');

        // Settings & Store Admin Profile
        Route::get('/settings', [AdminSettingsController::class, 'index'])->name('settings.index');
        Route::post('/settings/general', [AdminSettingsController::class, 'updateGeneral'])->name('settings.general');
        Route::post('/settings/profile', [AdminSettingsController::class, 'updateProfile'])->name('settings.profile');
        Route::post('/settings/credentials/otp', [AdminSettingsController::class, 'requestCredentialsOtp'])->name('settings.credentials.otp');
        Route::post('/settings/credentials', [AdminSettingsController::class, 'updateCredentials'])->name('settings.credentials');

        // Outlets Management (Limited by Store's max_outlets)
        Route::post('/outlets', [AdminOutletController::class, 'store'])->name('outlets.store');
        Route::put('/outlets/{outlet}', [AdminOutletController::class, 'update'])->name('outlets.update');
        Route::delete('/outlets/{outlet}', [AdminOutletController::class, 'destroy'])->name('outlets.destroy');

        // Store Invoices & Subscription Billing (Visible if NOT lifetime free)
        Route::get('/invoices', [AdminInvoiceController::class, 'index'])->name('invoices.index');
        Route::post('/invoices/{invoice}/pay', [AdminInvoiceController::class, 'submitPayment'])->name('invoices.pay');

        // Store User Manual
        Route::get('/user-manual', [UserManualController::class, 'storeIndex'])->name('user-manual.store');
    });
});

// Backward-compatibility redirect from /administration-control to /store
Route::get('/administration-control/{any?}', function ($any = null) {
    return redirect('/store/'.($any ? $any : 'login'));
})->where('any', '.*');

/*
|--------------------------------------------------------------------------
| Super Admin Portal Routes
|--------------------------------------------------------------------------
*/
require __DIR__.'/super-admin.php';

Route::get('/clear', function () {
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('config:cache');
    Artisan::call('view:clear');
    Artisan::call('storage:link');

    return 'Cleared!';
});
