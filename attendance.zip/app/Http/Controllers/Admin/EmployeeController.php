<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreEmployeeRequest;
use App\Http\Requests\Admin\UpdateEmployeeRequest;
use App\Models\Employee;
use App\Models\Outlet;
use App\Models\WebsiteSetting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Inertia\Response;

class EmployeeController extends Controller
{
    /**
     * Display a listing of employees for the authenticated admin's store.
     */
    public function index(Request $request): Response
    {
        $admin = Auth::guard('admin')->user();
        $search = $request->query('search');
        $status = $request->query('status');
        $outletId = $request->query('outlet_id');

        $query = $admin->employees()->with('outlet')->withCount('attendances')->orderBy('created_at', 'desc');

        if (! empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('uid', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%")
                    ->orWhere('role', 'like', "%{$search}%");
            });
        }

        if ($status !== null && $status !== '') {
            $query->where('status', (int) $status);
        }

        if (! empty($outletId) && $outletId !== 'all') {
            $query->where('outlet_id', (int) $outletId);
        }

        $employees = $query->paginate(15)->withQueryString();
        $settings = WebsiteSetting::forAdmin($admin->id);
        $outlets = $admin->outlets()->withCount('employees')->orderBy('name')->get();

        return Inertia::render('admin/employees/index', [
            'employees' => $employees,
            'outlets' => $outlets,
            'currencySymbol' => $settings->currency_symbol ?: 'BDT',
            'filters' => [
                'search' => $search ?? '',
                'status' => $status ?? '',
                'outlet_id' => $outletId ?? '',
            ],
            'defaultTimes' => [
                'check_in_time' => $settings->office_starting_time ?? '09:00:00',
                'check_out_time' => $settings->office_closing_time ?? '17:00:00',
            ],
            'appUrl' => url('/'),
        ]);
    }

    /**
     * Store a newly created employee for the authenticated store.
     */
    public function store(StoreEmployeeRequest $request): RedirectResponse
    {
        $admin = Auth::guard('admin')->user();
        $data = $request->validated();

        if (! empty($data['outlet_id'])) {
            $validOutlet = $admin->outlets()->where('id', $data['outlet_id'])->exists();
            if (! $validOutlet) {
                return back()->with('error', 'The selected outlet does not belong to your store.');
            }
        }

        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('employees/images', 'public');
        }

        if ($request->hasFile('appointment_letter')) {
            $data['appointment_letter'] = $request->file('appointment_letter')->store('employees/letters', 'public');
        }

        $data['admin_id'] = $admin->id;
        $employee = $admin->employees()->create($data);

        return redirect()->route('admin.employees.index')->with('success', "Employee '{$employee->name}' registered successfully. Verification link generated.");
    }

    /**
     * Update the specified employee.
     */
    public function update(UpdateEmployeeRequest $request, Employee $employee): RedirectResponse
    {
        $admin = Auth::guard('admin')->user();
        if ($employee->admin_id !== $admin->id) {
            abort(403, 'Unauthorized access to employee.');
        }

        $data = $request->validated();

        if (! empty($data['outlet_id'])) {
            $validOutlet = $admin->outlets()->where('id', $data['outlet_id'])->exists();
            if (! $validOutlet) {
                return back()->with('error', 'The selected outlet does not belong to your store.');
            }
        }

        if ($request->hasFile('image')) {
            if (! empty($employee->image) && Storage::disk('public')->exists($employee->image)) {
                Storage::disk('public')->delete($employee->image);
            }
            $data['image'] = $request->file('image')->store('employees/images', 'public');
        } else {
            $data['image'] = $employee->image;
        }

        if ($request->hasFile('appointment_letter')) {
            if (! empty($employee->appointment_letter) && Storage::disk('public')->exists($employee->appointment_letter)) {
                Storage::disk('public')->delete($employee->appointment_letter);
            }
            $data['appointment_letter'] = $request->file('appointment_letter')->store('employees/letters', 'public');
        } else {
            $data['appointment_letter'] = $employee->appointment_letter;
        }

        $employee->update($data);

        return redirect()->route('admin.employees.index')->with('success', "Employee '{$employee->name}' updated successfully.");
    }

    /**
     * Remove the specified employee.
     */
    public function destroy(Employee $employee): RedirectResponse
    {
        $admin = Auth::guard('admin')->user();
        if ($employee->admin_id !== $admin->id) {
            abort(403, 'Unauthorized access to employee.');
        }

        $name = $employee->name;
        $employee->delete();

        return redirect()->route('admin.employees.index')->with('success', "Employee '{$name}' and all associated attendance records & files were removed.");
    }

    /**
     * Re-verify / change device: generates new link, clears device hash, sets status to 0.
     */
    public function resetVerification(Employee $employee): RedirectResponse
    {
        $admin = Auth::guard('admin')->user();
        if ($employee->admin_id !== $admin->id) {
            abort(403, 'Unauthorized access to employee.');
        }

        $token = $employee->resetForReverification();
        $verifyLink = url("/verify/{$token}");

        return back()->with([
            'success' => "Device reset successfully! New verification link generated.",
            'new_verification_link' => $verifyLink,
        ]);
    }
}
