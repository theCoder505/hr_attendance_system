<?php

namespace App\Http\Middleware;

use App\Models\Employee;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class VerifyDeviceToken
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $rawToken = $request->header('X-Device-Token') 
            ?? $request->input('device_token') 
            ?? $request->cookie('device_token');

        if (! $rawToken) {
            return response()->json([
                'success' => false,
                'code' => 'DEVICE_NOT_VERIFIED',
                'message' => 'Device not verified, contact admin.',
            ], 403);
        }

        $hash = hash('sha256', $rawToken);

        $employee = Employee::with(['outlet', 'admin'])->where('device_token_hash', $hash)->first();

        if (! $employee || $employee->status !== 1) {
            return response()->json([
                'success' => false,
                'code' => 'DEVICE_NOT_VERIFIED',
                'message' => 'Device not verified or employee is inactive. Please contact admin.',
            ], 403);
        }

        if (empty($employee->device_token_expires_at) || now()->isAfter($employee->device_token_expires_at)) {
            return response()->json([
                'success' => false,
                'code' => 'DEVICE_TOKEN_EXPIRED',
                'message' => 'Your device session has expired. Please contact admin for re-verification.',
            ], 403);
        }

        // Verify Store ID (Admin Unique ID) if provided by employee browser cache
        $storeId = $request->header('X-Store-Id') ?? $request->input('store_id');
        $expectedStoreId = $employee->admin?->store_id ?? $employee->admin?->uid;
        if (! empty($expectedStoreId) && ! empty($storeId) && $storeId !== $expectedStoreId) {
            $storeName = $employee->admin?->name ?? 'another store';
            return response()->json([
                'success' => false,
                'code' => 'STORE_MISMATCH',
                'message' => "Device store mismatch. Assigned to store '{$storeName}' (ID: {$expectedStoreId}).",
            ], 403);
        }

        // Verify Outlet UID if provided by employee browser
        $outletUid = $request->header('X-Outlet-Uid') ?? $request->input('outlet_uid');
        if ($employee->outlet && ! empty($outletUid) && $outletUid !== $employee->outlet->uid) {
            return response()->json([
                'success' => false,
                'code' => 'OUTLET_MISMATCH',
                'message' => "Device outlet mismatch. Assigned to outlet '{$employee->outlet->name}'.",
            ], 403);
        }

        // Check if Store Attendance Service is Suspended due to Overdue Monthly Subscription
        if ($employee->admin && $employee->admin->isSuspended()) {
            return response()->json([
                'success' => false,
                'code' => 'STORE_SUSPENDED',
                'message' => "Attendance service for store '{$employee->admin->name}' is suspended due to overdue subscription payment. Please contact your store administrator to clear dues.",
                'store_name' => $employee->admin->name,
                'store_id' => $employee->admin->store_id,
                'redirect_url' => '/attendance/suspended',
            ], 402);
        }

        // Attach employee to request attributes for downstream use
        $request->attributes->set('employee', $employee);

        return $next($request);
    }
}
