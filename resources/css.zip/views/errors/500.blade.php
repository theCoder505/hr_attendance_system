@extends('errors.layout')

@section('title', '500 - Internal Server Error')
@section('code', '500')
@section('badge', 'Server Error')

@section('icon')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/>
    <line x1="12" y1="9" x2="12" y2="13"/>
    <line x1="12" y1="17" x2="12.01" y2="17"/>
</svg>
@endsection

@section('heading', 'Internal Server Error')

@section('message')
Something unexpected happened on our servers while processing your request. Our technical team has been notified. Please try refreshing or come back shortly.
@endsection

